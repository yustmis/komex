package com.list.lod.collector;

public enum Type {
	ONTO, FILE
}
