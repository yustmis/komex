package com.list.lod.collector;

public interface TripleWriter {
	public void writeResultToFile();
}
